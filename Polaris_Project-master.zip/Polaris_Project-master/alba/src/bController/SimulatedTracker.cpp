

// Project Header files
#include "SimulatedTracker.hpp"




/**
*@brief Initialize the V-REP simulator
*/
void SimulatedTracker::initVREP() {

}



